# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

print("{'user1':{}, 'user2':{}}")
print("Authorization: valid_unit_test_token")
print("Authorization: shadow_unit_test_token")