This directory contains the Swagger files that are used to generate the grammars
as well as the grammars themselves.

If the grammar definition in the RESTler compiler is updated, 
the grammars in this directory should be re-generated from the Swagger
files using the new version of the compiler.
